#!/usr/bin/env python3
"""
Example of use: district yield prediction benchmark.

Usage:
    python benchmark.py <package_root> <manuscript_dir>

For each crop, three feature sets are compared:
  F0  year + district (trend and level only)
  F1  F0 + the seven BMD station climate variables (calendar-year means)
  F2  F0 + the six CRU TS crop-season variables for the district
with three models (ridge regression, random forest, histogram gradient boosting) and two splits:
  temporal  train 1984-2015, test 2016-2023
  spatial   5-fold grouped cross-validation, groups = assigned BMD station (district identity not used)
Metrics: RMSE, R2, and the MSE skill score of the best model for a feature set relative to the best F0 model
(1 - MSE_best / MSE_best_F0; positive = climate adds predictive information beyond trend and location).
Add "report" as a third argument to rebuild the table and figure from tables/benchmark_results.csv without refitting.
Writes tables/benchmark_results.csv, tables/table_benchmark.tex, figures/fig10_benchmark.(pdf|png),
tables/facts_benchmark.json. Needs pandas, numpy, scikit-learn, matplotlib.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

PKG, OUT = (Path(a).resolve() for a in sys.argv[1:3])
FIG, TAB = OUT / "figures", OUT / "tables"
SEED = 0
CROPS = ["Aus", "Aman", "Boro", "Jute", "Potato"]
COL = dict(zip(CROPS, ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]))
BMD = ["max_temp_upper_c", "min_temp_c", "rainfall_mm", "relative_humidity_pct", "wind_speed", "cloud_coverage_okta",
       "bright_sunshine_hours"]
ERA = ["tmax_mean_c", "tmin_mean_c", "rain_total_mm", "vapour_pressure_hpa", "cloud_mean_okta", "wet_days"]

long = pd.read_csv(PKG / "data/processed/crop_climate_long.csv")
sea = pd.read_csv(PKG / "data/processed/cru_crop_season_climate.csv")
df = long.merge(sea[["district", "year", "crop"] + ERA].rename(columns={c: "s_" + c for c in ERA}),
                on=["district", "year", "crop"], how="left", validate="1:1")
assert df[["s_" + c for c in ERA]].isna().sum().sum() == 0
FEATS = {"F0": [], "F1": BMD, "F2": ["s_" + c for c in ERA]}


def model(kind, num, cat):
    if kind == "Ridge":
        pre = ColumnTransformer([("n", StandardScaler(), num)] +
                                ([("c", OneHotEncoder(handle_unknown="ignore"), cat)] if cat else []))
        return make_pipeline(pre, RidgeCV(alphas=np.logspace(-3, 3, 25)))
    if kind == "Random forest":
        pre = ColumnTransformer([("n", "passthrough", num)] +
                                ([("c", OneHotEncoder(handle_unknown="ignore"), cat)] if cat else []))
        return make_pipeline(pre, RandomForestRegressor(n_estimators=400, min_samples_leaf=3,
                                                        random_state=SEED, n_jobs=-1))
    pre = ColumnTransformer([("n", "passthrough", num)] +
                            ([("c", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat)] if cat else []))
    return make_pipeline(pre, HistGradientBoostingRegressor(max_iter=400, learning_rate=0.05,
                                                            random_state=SEED))


def run(d, split, fs, kind):
    num = ["year"] + FEATS[fs]
    cat = ["district"] if split == "temporal" else []
    y = d["yield"].values
    pred = np.full(len(d), np.nan)
    if split == "temporal":
        tr, te = d.year <= 2015, d.year >= 2016
        m = model(kind, num, cat).fit(d.loc[tr, num + cat], y[tr])
        pred[te.values] = m.predict(d.loc[te, num + cat])
        mask = te.values
    else:
        for tr, te in GroupKFold(n_splits=5).split(d, y, groups=d.station_name):
            m = model(kind, num, cat).fit(d.iloc[tr][num + cat], y[tr])
            pred[te] = m.predict(d.iloc[te][num + cat])
        mask = np.ones(len(d), bool)
    return y[mask], pred[mask]


if len(sys.argv) > 3 and sys.argv[3] == "report":
    res = pd.read_csv(TAB / "benchmark_results.csv")
else:
    rows = []
    for crop in CROPS:
        d = df[df.crop == crop].reset_index(drop=True)
        for split in ("temporal", "spatial"):
            for kind in ("Ridge", "Random forest", "Gradient boosting"):
                base_mse = None
                for fs in ("F0", "F1", "F2"):
                    obs, pr = run(d, split, fs, kind)
                    mse = mean_squared_error(obs, pr)
                    if fs == "F0":
                        base_mse = mse
                    rows.append({"crop": crop, "split": split, "model": kind, "features": fs, "n_test": len(obs),
                                 "rmse": np.sqrt(mse), "r2": r2_score(obs, pr),
                                 "skill_vs_F0": 1 - mse / base_mse, "mean_yield": float(obs.mean())})
                print(crop, split, kind, "done", flush=True)
    res = pd.DataFrame(rows)
    res.round(4).to_csv(TAB / "benchmark_results.csv", index=False)

# condensed LaTeX table: best model per crop x split x feature set (by RMSE), plus R2 and skill
best = res.loc[res.groupby(["crop", "split", "features"]).rmse.idxmin()].copy()
f0 = best[best.features == "F0"].set_index(["crop", "split"]).rmse
best["skill_vs_best_F0"] = [1 - (r.rmse / f0[(r.crop, r.split)]) ** 2 for _, r in best.iterrows()]
lines = ["\\begin{tabular}{lllrrrlrrr}", "\\toprule",
         " & & \\multicolumn{4}{c}{Temporal test, 2016-2023} & & \\multicolumn{3}{c}{Spatial (grouped CV)} \\\\",
         "\\cmidrule(lr){3-6}\\cmidrule(lr){8-10}",
         "Crop & Features & Best model & RMSE & $R^2$ & Skill & & RMSE & $R^2$ & Skill \\\\", "\\midrule"]
abbr = {"Ridge": "Ridge", "Random forest": "RF", "Gradient boosting": "GB"}
for crop in CROPS:
    for fs, lab in [("F0", "Trend"), ("F1", "+ station"), ("F2", "+ season")]:
        t = best[(best.crop == crop) & (best.split == "temporal") & (best.features == fs)].iloc[0]
        s = best[(best.crop == crop) & (best.split == "spatial") & (best.features == fs)].iloc[0]
        sk = lambda r: "" if fs == "F0" else f"{r.skill_vs_best_F0:+.2f}"
        lines.append(f"{crop if fs == 'F0' else ''} & {lab} & {abbr[t.model]} & {t.rmse:.3f} & {t.r2:.2f} & {sk(t)} & & "
                     f"{s.rmse:.3f} & {s.r2:.2f} & {sk(s)} \\\\")
    if crop != CROPS[-1]:
        lines.append("\\addlinespace")
lines += ["\\bottomrule", "\\end{tabular}"]
(TAB / "table_benchmark.tex").write_text("\n".join(lines) + "\n")

# figure: skill vs F0 for F1 and F2, best model per crop and split
fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7), sharey=True)
for ax, split, title in zip(axes, ("temporal", "spatial"), ("(a) Temporal test, 2016-2023", "(b) Spatial grouped CV")):
    x = np.arange(len(CROPS))
    for k, (fs, lab, hatch) in enumerate([("F1", "+ station climate (annual)", ""), ("F2", "+ crop-season climate", "")]):
        vals = []
        for crop in CROPS:
            sub = best[(best.crop == crop) & (best.split == split) & (best.features == fs)]
            vals.append(float(sub.skill_vs_best_F0.iloc[0]))
        ax.bar(x + (k - 0.5) * 0.36, vals, width=0.34, color=["#86b6ef", "#1c5cab"][k], label=lab)
    ax.axhline(0, color="#52514e", lw=0.6)
    ax.set_xticks(x, CROPS)
    ax.set_title(title, loc="left", fontsize=7.5)
    ax.grid(axis="x", visible=False)
axes[0].set_ylabel("MSE skill vs best trend-only model", fontsize=7)
axes[0].legend(fontsize=6.3, loc="upper left")
for a in axes:
    a.tick_params(labelsize=6.8)
    a.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG / "fig10_benchmark.pdf", dpi=300, bbox_inches="tight")
fig.savefig(FIG / "fig10_benchmark.png", dpi=300, bbox_inches="tight")
(TAB / "facts_benchmark.json").write_text(best.round(4).to_json(orient="records", indent=1))
print(best[["crop", "split", "features", "model", "rmse", "r2", "skill_vs_best_F0"]].round(3).to_string(index=False))
