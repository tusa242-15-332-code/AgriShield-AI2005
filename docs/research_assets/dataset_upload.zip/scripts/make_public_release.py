#!/usr/bin/env python3
"""
Make the public release from the authors' full build.

Usage:
    python make_public_release.py <full_package> <public_package>

The station climate values for 2014-2023 were purchased from the BMD climate data portal by a colleague of
the authors and are not redistributed. This script:
  1. writes the five compiled files to <public>/data/original/ with those values removed (empty cells);
  2. leaves the rest of each file unchanged.
Run build_package.py and add_external_layers.py on <public> afterwards, then this script again with
--finish to copy the full-data summaries (summary statistics, QC reports) and refresh the checksums.
Needs pandas.
"""
import hashlib
import shutil
import sys
from pathlib import Path

import pandas as pd

FULL, PUB = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
FINISH = "--finish" in sys.argv
CLIMATE_COLS = ["Max Temp", "Min Temp", "Rainfall", "Relative Humidity", "Wind Speed", "Cloud Coverage",
                "Bright Sunshine"]


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


if not FINISH:
    (PUB / "data/original").mkdir(parents=True, exist_ok=True)
    for f in sorted((FULL / "data/original").glob("*.csv")):
        df = pd.read_csv(f, dtype=str, keep_default_na=False)
        mask = df["YEAR"].astype(int) >= 2014
        df.loc[mask, CLIMATE_COLS] = ""
        df.to_csv(PUB / "data/original" / f.name, index=False)
        print(f.name, "rows with station values removed:", int(mask.sum()))
else:
    for rel in ["metadata/summary_statistics.csv", "metadata/qc_report.md", "metadata/qc_climate_flags.csv",
                "metadata/qc_yield_flags.csv"]:
        if (FULL / rel).exists():
            shutil.copy2(FULL / rel, PUB / rel)
    # QC flags list individual station values: remove the 2014-2023 BMD values from the public copy
    fl = PUB / "metadata/qc_climate_flags.csv"
    if fl.exists():
        q = pd.read_csv(fl)
        if "bmd_value" in q.columns:
            q.loc[q.year >= 2014, "bmd_value"] = pd.NA
            q.to_csv(fl, index=False)
    files = sorted(p for d in ("data", "metadata", "scripts") for p in (PUB / d).rglob("*")
                   if p.is_file() and p.name != "checksums_sha256.txt" and not p.name.startswith(".")
                   and "__pycache__" not in p.parts)
    (PUB / "metadata/checksums_sha256.txt").write_text(
        "".join(f"{sha256(p)}  {p.relative_to(PUB)}\n" for p in files))
    print("copied full-data summaries; checksums for", len(files), "files")
