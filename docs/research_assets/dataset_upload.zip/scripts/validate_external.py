#!/usr/bin/env python3
"""
Independent validation of the BBS crop and BMD climate records.

Usage:
    python validate_external.py <package_root> <downloads_dir> <manuscript_dir>

Checks
  A. BMD station climate vs NOAA GSOD daily reports from the same WMO stations and vs CRU TS 4.10 grids,
     1984-2023, including a test for a step at the 2013/2014 change of climate source.
  B. National rice totals vs USDA FAS PSD (milled rice), two year alignments.
  C. Documented extreme events: production change in affected districts vs the rest of the country.
  D. District rice yield anomalies vs GDHY v1.2+v1.3 (0.5 degree, satellite-informed), 1984-2016.
Writes tables/*.csv|tex, figures/fig7..fig9, tables/facts_external.json, and
<package>/metadata/qc_climate_flags.csv. Needs pandas, numpy, scipy, shapely, netCDF4, matplotlib.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import netCDF4
import numpy as np
import pandas as pd
from scipy import stats
from shapely.geometry import box, shape

PKG, DL, OUT = (Path(a).resolve() for a in sys.argv[1:4])
FIG, TAB = OUT / "figures", OUT / "tables"
safe = lambda s: s.replace(" ", "_").replace("'", "")
XW = {"Brahamanbaria": "Brahmanbaria", "Nawabganj": "Chapai Nawabganj",
      "Maulvibazar": "Moulvibazar", "Netrakona": "Netrokona"}
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7.5, "axes.titlesize": 8, "axes.edgecolor": MUTED,
    "axes.linewidth": 0.6, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "savefig.dpi": 300, "savefig.bbox": "tight", "pdf.fonttype": 42})
facts = {}
VARS = [("max_temp_upper_c", "Maximum temperature, as compiled (°C)"), ("min_temp_c", "Minimum temperature (°C)"),
        ("rainfall_mm", "Rainfall (mm per month)"), ("relative_humidity_pct", "Relative humidity (%)"),
        ("wind_speed", "Wind speed"), ("cloud_coverage_okta", "Cloud cover (okta)"),
        ("bright_sunshine_hours", "Bright sunshine (h per day)")]


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf")
    fig.savefig(FIG / f"{name}.png")
    plt.close(fig)


def detrend(y, x):
    b = np.polyfit(x, y, 1)
    return y - np.polyval(b, x)


# ============================================================ A. climate
clim = pd.read_csv(PKG / "data/processed/climate_by_district_year.csv")
bmd = clim.drop_duplicates(["station_name", "year"])[["station_name", "station_number", "latitude", "longitude", "year"]
                                                     + [v for v, _ in VARS]]
stations = bmd.drop_duplicates("station_name")[["station_name", "station_number", "latitude", "longitude"]]


def rh_from(t, td):
    es = lambda x: np.exp(17.625 * x / (243.04 + x))
    return 100 * es(td) / es(t)


def annual_gsod(num):
    """Annual values from NOAA GSOD daily reports by the anomaly method.

    A month is valid with at least 15 reported days. A year is kept when at least 10 months are valid; missing
    months are filled with the station's GSOD monthly normal plus the year's mean anomaly (additive for
    temperature, humidity and wind; proportional for rainfall).
    """
    parts = []
    for y in range(1984, 2024):
        f = DL / "gsod" / str(y) / f"{num}099999.csv"
        if f.exists() and f.stat().st_size > 0:
            parts.append(pd.read_csv(f, usecols=["DATE", "TEMP", "DEWP", "WDSP", "MAX", "MIN", "PRCP", "PRCP_ATTRIBUTES"]))
    if not parts:
        return None
    d = pd.concat(parts)
    d["date"] = pd.to_datetime(d.DATE)
    for c, miss in [("TEMP", 9999.9), ("DEWP", 9999.9), ("MAX", 9999.9), ("MIN", 9999.9), ("WDSP", 999.9), ("PRCP", 99.99)]:
        d.loc[d[c] >= miss, c] = np.nan
    f2c = lambda x: (x - 32) * 5 / 9
    d["tmax"], d["tmin"] = f2c(d.MAX), f2c(d.MIN)
    d["rh"] = rh_from(f2c(d.TEMP), f2c(d.DEWP))
    d["wind"] = d.WDSP                        # knots
    # PRCP flag 'I' = incomplete report: treat as missing
    d["rain"] = np.where(d.PRCP_ATTRIBUTES.astype(str).str.strip() == "I", np.nan, d.PRCP * 25.4)
    d["ym"] = d.date.dt.to_period("M")
    g = d.groupby("ym")
    out = pd.DataFrame(index=pd.Index(range(1984, 2024), name="year"), dtype=float)
    for k, v in [("tmax", "max_temp_upper_c"), ("tmin", "min_temp_c"), ("rh", "relative_humidity_pct"),
                 ("wind", "wind_speed"), ("rain", "rainfall_mm")]:
        m = g[k].mean().where(g[k].count() >= 15)
        if k == "rain":
            m = m * m.index.days_in_month          # monthly total
        mm = pd.DataFrame({"val": m, "year": m.index.year, "month": m.index.month}).dropna()
        clim = mm.groupby("month").val.mean()
        if len(clim) < 12:
            continue
        mm["clim"] = mm.month.map(clim)
        for y, gy in mm.groupby("year"):
            if len(gy) < 10:
                continue
            if k == "rain":
                out.loc[y, v] = gy.val.sum() / gy.clim.sum() * clim.sum() / 12   # mm per month
            else:
                out.loc[y, v] = clim.mean() + (gy.val - gy.clim).mean()
    return out


CRU_CACHE = {}


def cru_annual_at(lat, lon):
    out = {}
    for var in ["tmx", "tmn", "pre", "vap", "cld"]:
        if var not in CRU_CACHE:
            arrs, dates = [], []
            for dec in ["1981.1990", "1991.2000", "2001.2010", "2011.2020", "2021.2025"]:
                ds = netCDF4.Dataset(DL / "cru" / var / f"cru_ts4.10.{dec}.{var}.dat.nc")
                la, lo = ds["lat"][:], ds["lon"][:]
                t = netCDF4.num2date(ds["time"][:], ds["time"].units, only_use_cftime_datetimes=False)
                dates += [d.year for d in t]
                arrs.append((np.ma.filled(ds[var][:].astype(float), np.nan), np.ma.filled(ds["stn"][:].astype(float), np.nan)))
                ds.close()
            CRU_CACHE[var] = (la, lo, np.array(dates), np.concatenate([x[0] for x in arrs]),
                              np.concatenate([x[1] for x in arrs]))
        la, lo, yrs, arr, stn = CRU_CACHE[var]
        i, j = int(np.abs(la - lat).argmin()), int(np.abs(lo - lon).argmin())
        s = pd.DataFrame({"year": yrs, "v": arr[:, i, j], "stn": stn[:, i, j]})
        g = s.groupby("year")
        out[var] = g.v.sum() / 12 if var == "pre" else g.v.mean()
        out["stn_" + var] = g.stn.mean()
    o = pd.DataFrame(out)
    tmean = (o.tmx + o.tmn) / 2
    es = 6.1094 * np.exp(17.625 * tmean / (tmean + 243.04))
    return pd.DataFrame({"max_temp_upper_c": o.tmx, "min_temp_c": o.tmn, "rainfall_mm": o.pre,
                         "relative_humidity_pct": (100 * o.vap / es).clip(upper=100),
                         "cloud_coverage_okta": o.cld * 8 / 100,
                         "cru_stations": o.stn_tmx, "cru_stations_pre": o.stn_pre})


refs = {}
gs, cr = [], []
for _, r in stations.iterrows():
    a = annual_gsod(r.station_number)
    if a is not None:
        a = a.loc[1984:2023].reset_index().assign(station_name=r.station_name)
        gs.append(a)
    c = cru_annual_at(r.latitude, r.longitude).loc[1984:2023].reset_index().assign(station_name=r.station_name)
    cr.append(c)
refs["GSOD"] = pd.concat(gs, ignore_index=True)
refs["CRU TS 4.10"] = pd.concat(cr, ignore_index=True)
cru_st = refs["CRU TS 4.10"]
facts["cru_station_years_zero_tmx_stations"] = float((cru_st.cru_stations < 0.5).mean())
facts["cru_station_years_zero_pre_stations"] = float((cru_st.cru_stations_pre < 0.5).mean())
facts["gsod_stations_found"] = int(refs["GSOD"].station_name.nunique())
COMPARE = {"GSOD": ["max_temp_upper_c", "min_temp_c", "rainfall_mm", "relative_humidity_pct", "wind_speed"],
           "CRU TS 4.10": ["max_temp_upper_c", "min_temp_c", "rainfall_mm", "relative_humidity_pct", "cloud_coverage_okta"]}
LAB = dict(VARS)

rows, flags, bias_year = [], [], {}
for name, ref in refs.items():
    j0 = bmd.merge(ref, on=["station_name", "year"], suffixes=("", "_ref"))
    for v in COMPARE[name]:
        j = j0.dropna(subset=[v + "_ref"])
        if name == "CRU TS 4.10":
            j = j[j.cru_stations >= 0.5] if v != "rainfall_mm" else j[j.cru_stations_pre >= 0.5]
        x, y = j[v + "_ref"], j[v]
        r_pool = stats.pearsonr(x, y)[0]
        per, an_b, an_r = [], [], []
        for _, g in j.groupby("station_name"):
            if len(g) >= 8:
                per.append(stats.pearsonr(g[v + "_ref"], g[v])[0])
                an_b.append(detrend(g[v].values, g.year.values))
                an_r.append(detrend(g[v + "_ref"].values, g.year.values))
        r_anom = stats.pearsonr(np.concatenate(an_r), np.concatenate(an_b))[0]
        d = j.assign(diff=j[v] - j[v + "_ref"])
        pre = d[d.year <= 2013].groupby("station_name")["diff"].mean()
        post = d[d.year >= 2014].groupby("station_name")["diff"].mean()
        step = (post - pre).dropna()
        comparable = v != "wind_speed"
        t, p = stats.ttest_1samp(step, 0.0) if comparable and len(step) > 2 else (np.nan, np.nan)
        rows.append({"reference": name, "variable": LAB[v], "n": len(j), "n_stations": j.station_name.nunique(),
                     "r_pooled": r_pool, "r_station_median": float(np.median(per)), "r_anomaly": r_anom,
                     "bias_mean": float(d["diff"].mean()) if comparable else np.nan,
                     "step_2014_mean": float(step.mean()) if comparable else np.nan,
                     "step_2014_p": float(p) if comparable else np.nan,
                     "ratio_median": float(np.median(j[v] / j[v + "_ref"]))})
        key = (name, v)
        bias_year[key] = d.groupby("year")["diff"].mean() if comparable else None
        if comparable:
            for s, g in d.groupby("station_name"):
                if len(g) < 8:
                    continue
                z = (g["diff"] - g["diff"].mean()) / g["diff"].std()
                for _, rr in g[z.abs() > 3].iterrows():
                    flags.append({"station_name": s, "year": int(rr.year), "variable": v, "bmd_value": rr[v],
                                  "reference": name, "reference_value": round(rr[v + "_ref"], 3),
                                  "z_of_difference": round(float(z.loc[rr.name]), 2)})
cv = pd.DataFrame(rows)
cv.round(4).to_csv(TAB / "validation_climate.csv", index=False)
pd.DataFrame(flags).sort_values(["station_name", "year", "variable"]).to_csv(PKG / "metadata/qc_climate_flags.csv", index=False)
facts["climate_validation"] = cv.round(3).to_dict(orient="records")
facts["n_climate_flags"] = len(flags)
facts["n_climate_flags_by_reference"] = pd.DataFrame(flags).reference.value_counts().to_dict() if flags else {}
w = cv[(cv.reference == "GSOD") & (cv.variable == LAB["wind_speed"])].iloc[0]
facts["wind_ratio_bmd_over_gsod_knots"] = w.ratio_median


def f3(x, nd=2):
    return "" if pd.isna(x) else f"{x:.{nd}f}"


lines = ["\\begin{tabular}{llrrrrrr}", "\\toprule",
         "Reference & Variable & $n$ & $r$ & Anomaly $r$ & Bias & Step 2014 & $p$ \\\\", "\\midrule"]
last = None
for _, v in cv.iterrows():
    if last is not None and v.reference != last:
        lines.append("\\addlinespace")
    lab = v.variable.replace("°C", "\\textdegree C").replace("%", "\\%")
    p = "" if pd.isna(v.step_2014_p) else ("$<$0.001" if v.step_2014_p < 0.001 else f"{v.step_2014_p:.3f}")
    lines.append(f"{v.reference if v.reference != last else ''} & {lab} & {v.n} & {v.r_pooled:.2f} & "
                 f"{v.r_anomaly:.2f} & {f3(v.bias_mean)} & {f3(v.step_2014_mean)} & {p} \\\\")
    last = v.reference
lines += ["\\bottomrule", "\\end{tabular}"]
(TAB / "table_climate_validation.tex").write_text("\n".join(lines) + "\n")

# Fig 7: BMD against GSOD (top row) and CRU TS (bottom row)
fig, axes = plt.subplots(2, 5, figsize=(7.0, 3.5))
for row, name in enumerate(["GSOD", "CRU TS 4.10"]):
    j0 = bmd.merge(refs[name], on=["station_name", "year"], suffixes=("", "_ref"))
    for col, v in enumerate(COMPARE[name]):
        ax = axes[row, col]
        j = j0.dropna(subset=[v + "_ref"])
        if name == "CRU TS 4.10":
            j = j[j.cru_stations >= 0.5] if v != "rainfall_mm" else j[j.cru_stations_pre >= 0.5]
        ax.scatter(j[v + "_ref"], j[v], s=4, color=[BLUE, ORANGE][row], alpha=0.35, lw=0)
        lo, hi = np.nanmin([j[v].min(), j[v + "_ref"].min()]), np.nanmax([j[v].max(), j[v + "_ref"].max()])
        if v != "wind_speed":
            ax.plot([lo, hi], [lo, hi], ls="--", lw=0.7, color=MUTED)
        rr = cv[(cv.reference == name) & (cv.variable == LAB[v])].iloc[0]
        short = {"max_temp_upper_c": "Tmax (°C)", "min_temp_c": "Tmin (°C)", "rainfall_mm": "Rain (mm/month)",
                 "relative_humidity_pct": "RH (%)", "wind_speed": "Wind (GSOD knots)",
                 "cloud_coverage_okta": "Cloud (okta)"}[v]
        ax.set_title(short, loc="left", fontsize=6.5)
        ax.text(0.04, 0.95, f"r = {rr.r_pooled:.2f}", transform=ax.transAxes, va="top", fontsize=6)
        ax.tick_params(labelsize=5.5)
        if col == 0:
            ax.set_ylabel(f"BMD (vs {name.split()[0]})", fontsize=6.3)
fig.tight_layout()
save(fig, "fig7_climate_vs_references")

# Fig 8: mean BMD minus reference by year
fig, axes = plt.subplots(2, 3, figsize=(7.0, 3.6), sharex=True)
panels = [("max_temp_upper_c", "Tmax (°C)"), ("min_temp_c", "Tmin (°C)"), ("rainfall_mm", "Rain (mm/month)"),
          ("relative_humidity_pct", "RH (%)"), ("cloud_coverage_okta", "Cloud (okta)")]
for ax, (v, lab) in zip(axes.flat, panels):
    ax.axvspan(2013.5, 2023.5, color="#eeedea", lw=0)
    ax.axhline(0, color=MUTED, lw=0.6)
    for name, col in [("GSOD", BLUE), ("CRU TS 4.10", ORANGE)]:
        b = bias_year.get((name, v))
        if b is not None:
            ax.plot(b.index, b.values, color=col, lw=1.3, label=f"BMD minus {name}")
    ax.set_title(lab, loc="left", fontsize=7)
    ax.tick_params(labelsize=6)
axes.flat[-1].axis("off")
h, l = axes.flat[0].get_legend_handles_labels()
axes.flat[-1].legend(h, l, loc="center left", fontsize=6.5)
axes.flat[-1].text(0.02, 0.2, "Mean over stations.\nShaded: 2014-2023.", fontsize=6.3, color=INK2,
                   transform=axes.flat[-1].transAxes)
fig.tight_layout()
save(fig, "fig8_bias_by_year")

# ============================================================ B. USDA PSD
nat = pd.read_csv(PKG / "metadata/national_totals_by_year.csv").pivot(index="year", columns="crop",
                                                                         values=["area_acres", "production"])
psd = pd.read_csv(DL / "usda_psd/psd_grains_pulses.csv")
psd = psd[(psd.Country_Name == "Bangladesh") & psd.Commodity_Description.str.contains("Rice")
          & psd.Attribute_Description.isin(["Production", "Area Harvested"])]
psd = psd.pivot_table(index="Market_Year", columns="Attribute_Description", values="Value").loc[1984:2023] * 1000
ACRE_HA = 0.40468564224
align = {
    "same label": lambda t: (nat.loc[t, ("production", "Aus")] + nat.loc[t, ("production", "Aman")]
                             + nat.loc[t, ("production", "Boro")],
                             (nat.loc[t, ("area_acres", "Aus")] + nat.loc[t, ("area_acres", "Aman")]
                              + nat.loc[t, ("area_acres", "Boro")]) * ACRE_HA),
    "Aus and Aman of t, Boro of t+1": lambda t: (nat.loc[t, ("production", "Aus")] + nat.loc[t, ("production", "Aman")]
                                                 + nat.loc[t + 1, ("production", "Boro")],
                                                 (nat.loc[t, ("area_acres", "Aus")] + nat.loc[t, ("area_acres", "Aman")]
                                                  + nat.loc[t + 1, ("area_acres", "Boro")]) * ACRE_HA),
}
usda = []
for k, fn in align.items():
    yrs = [t for t in psd.index if t in nat.index and (t + 1 in nat.index or k == "same label")]
    ours = pd.DataFrame([fn(t) for t in yrs], index=yrs, columns=["prod", "area"])
    u = psd.loc[yrs]
    for meas, a, b in [("Production", ours["prod"], u["Production"]), ("Area", ours["area"], u["Area Harvested"])]:
        r, p = stats.pearsonr(a, b)
        r_d = stats.pearsonr(np.diff(np.log(a.values)), np.diff(np.log(b.values)))[0]
        usda.append({"alignment": k, "measure": meas, "n": len(yrs), "r": r, "p": p, "r_year_to_year": r_d,
                     "median_ratio": float(np.median(a / b))})
usda = pd.DataFrame(usda)
usda.round(4).to_csv(TAB / "validation_usda.csv", index=False)
facts["usda"] = usda.round(4).to_dict(orient="records")

# ============================================================ C. extreme events
long = pd.read_csv(PKG / "data/processed/crop_climate_long.csv")
EVENTS = [
    ("1988 monsoon flood", "Aman", 1988, None),
    ("1998 monsoon flood", "Aman", 1998, None),
    ("2007 Cyclone Sidr", "Aman", 2007, ["Bagerhat", "Barguna", "Patuakhali", "Pirojpur"]),
    ("2017 haor flash flood", "Boro", 2017, ["Sunamganj", "Sylhet", "Moulvibazar", "Habiganj", "Netrokona",
                                             "Kishoreganj", "Brahmanbaria"]),
]
ev = []
for name, crop, y, dists in EVENTS:
    c = long[long.crop == crop].pivot(index="year", columns="district", values="production")
    base = c.loc[y - 3:y - 1].mean()
    chg = (c.loc[y] / base - 1) * 100
    nat_chg = (c.loc[y].sum() / base.sum() - 1) * 100
    if dists:
        aff = (c.loc[y, dists].sum() / base[dists].sum() - 1) * 100
        others = [d for d in c.columns if d not in dists]
        oth = (c.loc[y, others].sum() / base[others].sum() - 1) * 100
        worst = chg[dists].idxmin()
        ev.append({"event": name, "crop": crop, "year": y, "affected": ", ".join(dists),
                   "change_affected_pct": aff, "change_other_pct": oth, "change_national_pct": nat_chg,
                   "worst_district": worst, "worst_change_pct": chg[worst],
                   "n_districts_falling": int((chg < 0).sum())})
    else:
        worst = chg.idxmin()
        ev.append({"event": name, "crop": crop, "year": y, "affected": "national",
                   "change_affected_pct": nat_chg, "change_other_pct": np.nan, "change_national_pct": nat_chg,
                   "worst_district": worst, "worst_change_pct": chg[worst],
                   "n_districts_falling": int((chg < 0).sum())})
ev = pd.DataFrame(ev)
sea = pd.read_csv(PKG / "data/processed/cru_crop_season_climate.csv")
rain_ratio = []
for _, e in ev.iterrows():
    dd = e.affected.split(", ") if e.affected != "national" else sorted(sea.district.unique())
    s_ = sea[(sea.crop == e.crop) & sea.district.isin(dd)].groupby("year")[["rain_total_mm", "wet_days"]].mean()
    rain_ratio.append((s_.loc[e.year, "rain_total_mm"] / s_.rain_total_mm.median(),
                       s_.loc[e.year, "wet_days"], s_.wet_days.median()))
ev["season_rain_vs_median"] = [r[0] for r in rain_ratio]
ev["season_wet_days"] = [r[1] for r in rain_ratio]
ev["season_wet_days_median"] = [r[2] for r in rain_ratio]
ev.round(2).to_csv(TAB / "validation_events.csv", index=False)
facts["events"] = ev.round(2).to_dict(orient="records")

lines = ["\\begin{tabular}{llrrrl}", "\\toprule",
         "Event & Crop, year & Affected (\\%) & Other districts (\\%) & Falling & Largest fall (\\%) \\\\", "\\midrule"]
for _, e in ev.iterrows():
    aff = "national" if e.affected == "national" else f"{len(e.affected.split(','))} districts"
    oth = "" if pd.isna(e.change_other_pct) else f"{e.change_other_pct:+.1f}"
    lines.append(f"{e.event} & {e.crop}, {e.year} & {e.change_affected_pct:+.1f} ({aff}) & {oth} & "
                 f"{e.n_districts_falling}/64 & {e.worst_district} ({e.worst_change_pct:+.1f}) \\\\")
lines += ["\\bottomrule", "\\end{tabular}"]
(TAB / "table_events.tex").write_text("\n".join(lines) + "\n")

# ============================================================ D. GDHY
gj = json.load(open(DL / "geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson"))
poly = {XW.get(f["properties"]["shapeName"], f["properties"]["shapeName"]): shape(f["geometry"]) for f in gj["features"]}
ds0 = netCDF4.Dataset(DL / "gdhy/rice/yield_1984.nc4")
lat, lon = ds0["lat"][:], ds0["lon"][:]
ii = np.where((lat > 20) & (lat < 27))[0]
jj = np.where((lon > 87.5) & (lon < 93))[0]
weights = {}
for d, pg in poly.items():
    w = []
    for i in ii:
        for k in jj:
            cell = box(lon[k] - 0.25, lat[i] - 0.25, lon[k] + 0.25, lat[i] + 0.25)
            a = pg.intersection(cell).area
            if a > 0:
                w.append((i, k, a))
    weights[d] = w


def gdhy_series(sub):
    out = {}
    for y in range(1984, 2017):
        v = np.ma.filled(netCDF4.Dataset(DL / f"gdhy/{sub}/yield_{y}.nc4")["var"][:], np.nan)
        row = {}
        for d, w in weights.items():
            vals = np.array([v[i, k] for i, k, _ in w])
            ws = np.array([a for _, _, a in w])
            ok = np.isfinite(vals)
            row[d] = np.sum(vals[ok] * ws[ok]) / ws[ok].sum() if ok.any() else np.nan
        out[y] = row
    return pd.DataFrame(out).T


ours = long[long.year <= 2016]
rice = ours[ours.crop.isin(["Aus", "Aman", "Boro"])].groupby(["year", "district"])[["production", "area_acres"]].sum()
rice = (rice.production / rice.area_acres).unstack()
pairs = {"All rice (production-weighted)": ("rice", rice),
         "Aman vs GDHY major season": ("rice_major", ours[ours.crop == "Aman"].pivot(index="year", columns="district", values="yield")),
         "Boro vs GDHY second season": ("rice_second", ours[ours.crop == "Boro"].pivot(index="year", columns="district", values="yield"))}
gd = []
gd_r = {}
for lab, (sub, mine) in pairs.items():
    g = gdhy_series(sub)
    yrs = np.arange(1984, 2017)
    rs, rs_rel = [], []
    A_m = mine.apply(lambda s: detrend(s.values, yrs) / s.mean())
    A_g = g.apply(lambda s: detrend(s.values, yrs) / s.mean() if s.notna().all() else s * np.nan)
    rel_m = A_m.sub(A_m.mean(axis=1), axis=0)
    rel_g = A_g.sub(A_g.mean(axis=1), axis=0)
    for d in mine.columns:
        if A_g[d].notna().all():
            rs.append(stats.pearsonr(A_m[d], A_g[d])[0])
            rs_rel.append(stats.pearsonr(rel_m[d], rel_g[d])[0])
    nat_r = stats.pearsonr(A_m.mean(axis=1), A_g.mean(axis=1))[0]
    mm = pd.concat([mine.mean(), g.mean()], axis=1, keys=["mine", "gdhy"]).dropna()
    sp = stats.pearsonr(mm["mine"], mm["gdhy"])[0]
    gd_r[lab] = (rs, rs_rel)
    gd.append({"comparison": lab, "n_districts": len(rs), "national_anomaly_r": nat_r,
               "district_anomaly_r_median": float(np.median(rs)), "share_positive": float(np.mean(np.array(rs) > 0)),
               "relative_anomaly_r_median": float(np.median(rs_rel)),
               "share_positive_relative": float(np.mean(np.array(rs_rel) > 0)),
               "spatial_r_of_means": sp})
gd = pd.DataFrame(gd)
gd.round(4).to_csv(TAB / "validation_gdhy.csv", index=False)
facts["gdhy"] = gd.round(3).to_dict(orient="records")

# Fig 9: events (a) and GDHY (b)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.9), gridspec_kw={"width_ratios": [1.2, 1]})
labels = [f"{e.event}\n({e.crop})" for _, e in ev.iterrows()]
yv = np.arange(len(ev))
a1.barh(yv + 0.18, ev.change_affected_pct, height=0.34, color=ORANGE, label="Affected districts (or national)")
a1.barh(yv - 0.18, ev.change_other_pct.fillna(0), height=0.34, color=MUTED, label="Other districts")
a1.axvline(0, color=INK2, lw=0.6)
a1.set_yticks(yv, labels, fontsize=6.3)
a1.invert_yaxis()
a1.set_xlabel("Production change vs previous 3-year mean (%)")
a1.legend(fontsize=6, loc="upper left", bbox_to_anchor=(0.0, 1.0))
a1.set_title("(a) Documented extreme events", loc="left", fontsize=7.5)
data = [gd_r[k][0] for k in pairs] + [gd_r[k][1] for k in pairs]
pos = [1, 2, 3, 5, 6, 7]
bp = a2.boxplot(data, positions=pos, widths=0.6, patch_artist=True, showfliers=False,
                medianprops=dict(color=INK, lw=1))
for i, b in enumerate(bp["boxes"]):
    b.set(facecolor=[BLUE, ORANGE, AQUA][i % 3], alpha=0.8, edgecolor=INK2, lw=0.6)
for p_, d_ in zip(pos, data):
    a2.scatter(np.full(len(d_), p_) + np.random.default_rng(1).uniform(-0.18, 0.18, len(d_)), d_, s=3, color=INK2, alpha=0.5, zorder=3)
a2.axhline(0, color=MUTED, lw=0.6)
a2.set_xticks([2, 6], ["District anomalies", "Relative to national"], fontsize=6.5)
a2.set_ylabel("Correlation with GDHY, 1984-2016", fontsize=6.5)
a2.set_title("(b) District rice yields vs GDHY", loc="left", fontsize=7.5)
from matplotlib.patches import Patch
a2.legend(handles=[Patch(fc=c, alpha=0.8, label=l) for c, l in zip([BLUE, ORANGE, AQUA],
          ["All rice", "Aman vs major", "Boro vs second"])], fontsize=5.8, loc="upper center",
          bbox_to_anchor=(0.5, -0.12), ncol=3)
fig.tight_layout()
save(fig, "fig9_events_gdhy")

(TAB / "facts_external.json").write_text(json.dumps(facts, indent=1, default=float))
print(cv.round(2).to_string(index=False))
print(usda.round(3).to_string(index=False))
print(ev.round(1).to_string(index=False))
print(gd.round(3).to_string(index=False))
print("climate flags:", len(flags))
