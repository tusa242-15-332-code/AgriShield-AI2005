#!/usr/bin/env python3
"""
Build the repository package for the Bangladesh district-level crop + climate dataset (1984-2023).

Usage:
    python3 build_package.py <folder_with_original_csvs> <package_root>

What it does (no original value is modified):
  1. Copies the 5 original CSVs byte-for-byte into data/original/.
  2. Writes tidy, unit-labelled files to data/processed/:
       - climate_by_district_year.csv   (climate + station location, one copy)
       - crop_<name>.csv                (crop variables per district-year)
       - crop_climate_long.csv          (all crops stacked, one row per district-year-crop)
       - crop_climate_wide.csv          (one row per district-year, all crops side by side)
  3. Writes metadata/: data dictionary, district-station mapping, summary statistics,
     national totals by year, QC report, SHA-256 checksums.
  4. Verifies that every processed value equals the corresponding original value.
"""
import hashlib
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SRC = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()

ORIG_FILES = {
    "aman": "Final_data - Aman.csv",
    "aus": "Final_data - Aus.csv",
    "boro": "Final_data - Boro2.csv",
    "jute": "Final_data - Jute.csv",
    "potato": "Final_data - Potato.csv",
}

# Original column -> processed column (shared climate / location block)
CLIMATE_MAP = {
    "District": "district",
    "Station Names": "station_name",
    "Station Number": "station_number",
    "YEAR": "year",
    "Max Temp": "max_temp_upper_c",
    "Min Temp": "min_temp_c",
    "Rainfall": "rainfall_mm",
    "Relative Humidity": "relative_humidity_pct",
    "Wind Speed": "wind_speed",
    "Cloud Coverage": "cloud_coverage_okta",
    "Bright Sunshine": "bright_sunshine_hours",
    "LATITUDE": "latitude",
    "LONGITUDE": "longitude",
    "ALT": "altitude_m",
    "X_COR": "x_btm_m",
    "Y_COR": "y_btm_m",
}
CLIMATE_VARS = ["max_temp_upper_c", "min_temp_c", "rainfall_mm", "relative_humidity_pct",
                "wind_speed", "cloud_coverage_okta", "bright_sunshine_hours"]
LOCATION_VARS = ["station_number", "latitude", "longitude", "altitude_m", "x_btm_m", "y_btm_m"]

# Original crop columns -> processed crop columns, per crop
CROP_MAP = {
    "aman": {"Area": "area_acres", "Aman": "production_t", "Aman/Area": "yield_t_per_acre"},
    "aus": {"Area": "area_acres", "AUS": "production_t", "AUS/Area": "yield_t_per_acre"},
    "boro": {"Area": "area_acres", "Boro": "production_t",
             "Boro(tons)": "production_short_tons", "Boro/Area": "yield_short_tons_per_acre"},
    "jute": {"Area": "area_acres", "Jute": "production_bales", "Jute/Area": "yield_bales_per_acre"},
    "potato": {"Area": "area_acres", "Potato": "production_t", "Potato/Area": "yield_t_per_acre"},
}
# Columns dropped from processed files (kept in data/original/)
DROPPED = {"SL. NO": "row serial number", "Period": "equals YEAR + 0.01",
           "Month": "Aus file only; constant value 1"}

KEYS = ["district", "station_name", "year"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    for d in ["data/original", "data/processed", "metadata"]:
        (OUT / d).mkdir(parents=True, exist_ok=True)

    # 1. originals, byte-for-byte
    raw = {}
    for crop, fn in ORIG_FILES.items():
        if (SRC / fn).resolve() != (OUT / "data/original" / fn).resolve():
            shutil.copy2(SRC / fn, OUT / "data/original" / fn)
        assert sha256(SRC / fn) == sha256(OUT / "data/original" / fn)
        raw[crop] = pd.read_csv(SRC / fn)

    qc = []  # (check, result, detail)

    # 2a. climate block — must be identical across all five files
    clim_cols = list(CLIMATE_MAP)
    base = raw["aman"][clim_cols]
    for crop, df in raw.items():
        same = df[clim_cols].equals(base)
        qc.append((f"Climate/location columns in {ORIG_FILES[crop]} identical to Aman file", same, ""))
        assert same
    climate = base.rename(columns=CLIMATE_MAP)
    # Source of the station climate values: the Kaggle compilation of BMD records (1984-2013) or BMD directly
    # (2014-2023). The validation shows a step between the two periods, so the flag travels with every row.
    # In the public release the 2014-2023 values (purchased from the BMD climate data portal) are not
    # redistributed; those rows are empty and marked bmd_not_included.
    _withheld = climate[CLIMATE_VARS].isna().all(axis=1)
    climate["climate_source"] = np.where(climate["year"] <= 2013, "kaggle_compilation",
                                         np.where(_withheld, "bmd_not_included", "bmd_direct"))
    climate = climate[KEYS + ["climate_source"] + LOCATION_VARS + CLIMATE_VARS].sort_values(["district", "year"]).reset_index(drop=True)
    climate.to_csv(OUT / "data/processed/climate_by_district_year.csv", index=False)

    # 2b. per-crop files
    crops = {}
    for crop, df in raw.items():
        c = df[["District", "Station Names", "YEAR"] + list(CROP_MAP[crop])].rename(
            columns={"District": "district", "Station Names": "station_name", "YEAR": "year", **CROP_MAP[crop]})
        if crop == "boro":
            # Only newly derived value in the package: Boro yield in metric tonnes per acre,
            # so all three rice seasons share one yield unit.
            c["yield_t_per_acre"] = (c["production_t"] / c["area_acres"]).round(9)  # 9 dp = precision of original yield columns
        c = c.sort_values(["district", "year"]).reset_index(drop=True)
        c.to_csv(OUT / f"data/processed/crop_{crop}.csv", index=False)
        crops[crop] = c

    # 2c. long table (Boro expressed in metric tonnes for consistency)
    long_parts = []
    for crop, c in crops.items():
        if crop == "jute":
            prod, yld, pu, yu = "production_bales", "yield_bales_per_acre", "bales", "bales/acre"
        else:
            prod, yld, pu, yu = "production_t", "yield_t_per_acre", "t", "t/acre"
        part = c[KEYS + ["area_acres", prod, yld]].rename(columns={prod: "production", yld: "yield"})
        part.insert(3, "crop", crop.capitalize())
        part["production_unit"] = pu
        part["yield_unit"] = yu
        long_parts.append(part)
    long = pd.concat(long_parts, ignore_index=True).merge(climate, on=KEYS, how="left", validate="m:1")
    long = long[KEYS + ["crop", "area_acres", "production", "production_unit", "yield", "yield_unit", "climate_source"]
                + LOCATION_VARS + CLIMATE_VARS].sort_values(["crop", "district", "year"]).reset_index(drop=True)
    long.to_csv(OUT / "data/processed/crop_climate_long.csv", index=False)

    # 2d. wide table
    wide = climate.copy()
    for crop, c in crops.items():
        cols = [x for x in c.columns if x not in KEYS]
        wide = wide.merge(c.rename(columns={x: f"{crop}_{x}" for x in cols}), on=KEYS, how="left", validate="1:1")
    wide.to_csv(OUT / "data/processed/crop_climate_wide.csv", index=False)

    # 3. verification: processed values == original values
    for crop, df in raw.items():
        o = df.sort_values(["District", "YEAR"]).reset_index(drop=True)
        p = crops[crop]
        for oc, pc in CROP_MAP[crop].items():
            assert (o[oc].values == p[pc].values).all(), (crop, oc)
        w = wide.sort_values(["district", "year"]).reset_index(drop=True)
        for oc, pc in CROP_MAP[crop].items():
            assert (o[oc].values == w[f"{crop}_{pc}"].values).all(), (crop, oc, "wide")
        for oc, pc in CLIMATE_MAP.items():
            assert o[oc].reset_index(drop=True).equals(w[pc].reset_index(drop=True)), (crop, oc, "climate")
    # reload written CSVs and compare with in-memory frames (catches float formatting loss)
    for crop, c in crops.items():
        back = pd.read_csv(OUT / f"data/processed/crop_{crop}.csv", float_precision="round_trip")
        pd.testing.assert_frame_equal(back, c, check_exact=True)
    pd.testing.assert_frame_equal(pd.read_csv(OUT / "data/processed/climate_by_district_year.csv", float_precision="round_trip"), climate,
                                  check_exact=True)
    qc.append(("Every processed value equals the original value (exact comparison, after CSV round-trip)", True, ""))

    # 4. QC checks
    for crop, df in raw.items():
        c = crops[crop]
        qc.append((f"{crop}: rows", True, f"{len(c)}"))
        crop_cols = [c for c in CROP_MAP[crop]]
        n_miss = int(df[crop_cols].isna().sum().sum()) + int(df.loc[df.YEAR <= 2013, list(CLIMATE_MAP)].isna().sum().sum())
        n_wh = int(df.loc[df.YEAR >= 2014, ["Max Temp"]].isna().sum().sum())
        qc.append((f"{crop}: missing values (excluding withheld 2014-2023 station values)", n_miss == 0,
                   f"{n_miss}; withheld district-years: {n_wh}"))
        dup = int(c.duplicated(["district", "year"]).sum())
        qc.append((f"{crop}: duplicate district-year rows", dup == 0, f"{dup}"))
        yrs = c.groupby("district").year.agg(["min", "max", "nunique"])
        full = bool(((yrs["min"] == 1984) & (yrs["max"] == 2023) & (yrs["nunique"] == 40)).all())
        qc.append((f"{crop}: every district has all 40 years 1984-2023", full, ""))
        pcol = [v for k, v in CROP_MAP[crop].items() if v.startswith("production")][0]
        pos = bool((c["area_acres"] > 0).all() and (c[pcol] > 0).all())
        qc.append((f"{crop}: area and production strictly positive", pos, ""))
        # yield ratio consistency
        if crop == "boro":
            dev = float(np.abs(c["production_short_tons"] / c["area_acres"] - c["yield_short_tons_per_acre"]).max())
            fac = c["production_short_tons"] / c["production_t"]
            qc.append(("boro: production_short_tons / production_t constant", bool(np.allclose(fac, 1.10231131)),
                       f"factor = {fac.min():.8f}-{fac.max():.8f} (metric tonne -> short ton)"))
        else:
            ycol = [v for v in CROP_MAP[crop].values() if v.startswith("yield")][0]
            dev = float(np.abs(c[pcol] / c["area_acres"] - c[ycol]).max())
        qc.append((f"{crop}: original yield column = production / area", dev < 1e-6, f"max abs deviation {dev:.2e}"))

    nd, ns = climate.district.nunique(), climate.station_name.nunique()
    qc.append(("Districts / stations", True, f"{nd} districts, {ns} stations"))
    const = climate.groupby("district")[["station_name"] + LOCATION_VARS].nunique().max().max() == 1
    qc.append(("Each district is linked to exactly one station for all years", bool(const), ""))
    sy = climate.groupby(["station_name", "year"])[CLIMATE_VARS].nunique().max().max() == 1
    qc.append(("Districts sharing a station have identical climate values in a given year", bool(sy), ""))
    _ok = climate.dropna(subset=["min_temp_c", "max_temp_upper_c"])
    qc.append(("min_temp_c < max_temp_upper_c in every row with values", bool((_ok.min_temp_c < _ok.max_temp_upper_c).all()), ""))
    qc.append(("relative_humidity_pct within 0-100", bool(climate.relative_humidity_pct.dropna().between(0, 100).all()), ""))
    qc.append(("cloud_coverage_okta within 0-8", bool(climate.cloud_coverage_okta.dropna().between(0, 8).all()), ""))
    qc.append(("bright_sunshine_hours within 0-24", bool(climate.bright_sunshine_hours.dropna().between(0, 24).all()), ""))

    # robust outlier screen on yield within each district (flag only, nothing removed)
    flags = []
    for part in long_parts:
        g = part.groupby("district")["yield"]
        med = g.transform("median")
        mad = g.transform(lambda s: (s - s.median()).abs().median())
        rz = 0.6745 * (part["yield"] - med) / mad.replace(0, np.nan)
        f = part.loc[rz.abs() > 3.5, ["crop", "district", "year", "yield", "yield_unit"]].copy()
        f["robust_z"] = rz[rz.abs() > 3.5].round(2)
        flags.append(f)
    flags = pd.concat(flags).sort_values(["crop", "district", "year"])
    flags.to_csv(OUT / "metadata/qc_yield_flags.csv", index=False)

    # 5. metadata tables
    m = climate.drop_duplicates("district")[["district", "station_name"] + LOCATION_VARS].sort_values("district")
    m["n_districts_sharing_station"] = m.groupby("station_name").district.transform("count")
    m.to_csv(OUT / "metadata/district_station_mapping.csv", index=False)

    stats = []
    def describe(df, cols, table):
        for col in cols:
            s = df[col]
            stats.append({"table": table, "variable": col, "n": int(s.count()), "mean": s.mean(), "sd": s.std(),
                          "min": s.min(), "q1": s.quantile(.25), "median": s.median(), "q3": s.quantile(.75),
                          "max": s.max()})
    # climate stats at station-year level (avoid counting shared stations several times)
    describe(climate.drop_duplicates(["station_name", "year"]), CLIMATE_VARS, "climate (station-year, n=26x40)")
    for crop, c in crops.items():
        describe(c, [x for x in c.columns if x not in KEYS], f"crop_{crop} (district-year)")
    pd.DataFrame(stats).round(4).to_csv(OUT / "metadata/summary_statistics.csv", index=False)

    nat = []
    for part in long_parts:
        g = part.groupby(["crop", "year"]).agg(area_acres=("area_acres", "sum"), production=("production", "sum"),
                                                production_unit=("production_unit", "first")).reset_index()
        g["yield"] = g["production"] / g["area_acres"]
        nat.append(g)
    pd.concat(nat).round(4).to_csv(OUT / "metadata/national_totals_by_year.csv", index=False)

    # QC report (markdown)
    lines = ["# Quality-control report", "", "Generated by `scripts/build_package.py`. Nothing was removed or altered;",
             "flags are informational.", "", "| Check | Pass | Detail |", "|---|---|---|"]
    for chk, ok, det in qc:
        lines.append(f"| {chk} | {'yes' if ok else '**NO**'} | {det} |")
    lines += ["", f"## Yield values flagged by robust z-score (|z| > 3.5 within district): {len(flags)}", "",
              "Listed in `metadata/qc_yield_flags.csv`. Per crop: "
              + ", ".join(f"{k} {v}" for k, v in flags.crop.value_counts().sort_index().items()) + ".",
              "These are values far from the district's own 40-year median. Many reflect real yield growth",
              "over time (early years low, recent years high) or genuine bad seasons, not errors.",
              "They should be cross-checked against the BBS source tables, not deleted.", "",
              "## Columns dropped from processed files (still present in data/original/)", ""]
    lines += [f"- `{k}`: {v}" for k, v in DROPPED.items()]
    (OUT / "metadata/qc_report.md").write_text("\n".join(lines) + "\n")

    # checksums (written last)
    files = sorted(p for d in ("data", "metadata", "scripts") for p in (OUT / d).rglob("*")
                   if p.is_file() and p.name != "checksums_sha256.txt" and not p.name.startswith(".")
                   and "__pycache__" not in p.parts)
    (OUT / "metadata/checksums_sha256.txt").write_text(
        "".join(f"{sha256(p)}  {p.relative_to(OUT)}\n" for p in files))

    print("OK")
    for chk, ok, det in qc:
        if not ok:
            print("QC FAIL:", chk, det)
    print("Yield flags:", len(flags), flags.crop.value_counts().to_dict())


if __name__ == "__main__":
    main()
