#!/usr/bin/env python3
"""
Figures, tables and derived facts for the Data in Brief article.

Usage:
    python make_figures_tables.py <package_root> <downloads_dir> <manuscript_dir>

Reads (never modifies) the repository package, plus two external files:
  <downloads_dir>/faostat/Production_Crops_Livestock_E_Asia_NOFLAG.csv   (FAOSTAT QCL bulk, Asia)
  <downloads_dir>/faostat/Production_Crops_Livestock_E_Asia.csv          (same, with flags)
  <downloads_dir>/geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson (district polygons)
Writes figures/*.pdf|png, tables/*.tex|csv and tables/facts.json under <manuscript_dir>.
Needs matplotlib, shapely, pandas, scipy.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon as MplPolygon
import numpy as np
import pandas as pd
from scipy import stats
from shapely.geometry import Point, shape

PKG, DL, OUT = (Path(a).resolve() for a in sys.argv[1:4])
FIG, TAB = OUT / "figures", OUT / "tables"
FIG.mkdir(parents=True, exist_ok=True)
TAB.mkdir(parents=True, exist_ok=True)

ACRE_HA = 0.40468564224          # 1 acre in hectares
JUTE_BALE_T = 0.18               # 1 bale of jute = 180 kg
CROPS = ["Aus", "Aman", "Boro", "Jute", "Potato"]
# dataviz reference palette, categorical slots 1-5 (validated: adjacent CVD dE >= 9.1, light mode)
COL = dict(zip(CROPS, ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]))
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1"
CLIM = [("max_temp_upper_c", "Maximum temperature, as compiled (°C)"), ("min_temp_c", "Minimum temperature (°C)"),
        ("rainfall_mm", "Rainfall (mm per month)"), ("relative_humidity_pct", "Relative humidity (%)"),
        ("wind_speed", "Wind speed"), ("cloud_coverage_okta", "Cloud cover (okta)"),
        ("bright_sunshine_hours", "Bright sunshine (h per day)")]
NAME_XWALK = {"Brahamanbaria": "Brahmanbaria", "Nawabganj": "Chapai Nawabganj",
              "Maulvibazar": "Moulvibazar", "Netrakona": "Netrokona"}

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7.5, "axes.titlesize": 8, "axes.labelsize": 7.5,
    "axes.edgecolor": MUTED, "axes.linewidth": 0.6, "axes.labelcolor": INK2, "axes.titlecolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "savefig.dpi": 300, "savefig.bbox": "tight", "pdf.fonttype": 42,
})
facts = {}


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf")
    fig.savefig(FIG / f"{name}.png")
    plt.close(fig)


# ------------------------------------------------------------------ load
long = pd.read_csv(PKG / "data/processed/crop_climate_long.csv")
clim = pd.read_csv(PKG / "data/processed/climate_by_district_year.csv")
nat = pd.read_csv(PKG / "metadata/national_totals_by_year.csv")
stats_tbl = pd.read_csv(PKG / "metadata/summary_statistics.csv")
mapping = pd.read_csv(PKG / "metadata/district_station_mapping.csv")
station_year = clim.drop_duplicates(["station_name", "year"])

# ------------------------------------------------------------------ 1a. station assignment facts
gj = json.load(open(DL / "geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson"))
poly = {NAME_XWALK.get(f["properties"]["shapeName"], f["properties"]["shapeName"]): shape(f["geometry"])
        for f in gj["features"]}
assert set(poly) == set(mapping.district), "district names do not match boundaries"
stations = mapping.drop_duplicates("station_name").set_index("station_name")[["latitude", "longitude"]]


def km(p, q):  # equirectangular distance, adequate at Bangladesh latitudes
    lat = np.radians((p.y + q.y) / 2)
    return float(np.hypot((p.x - q.x) * 111.32 * np.cos(lat), (p.y - q.y) * 110.57))


def host_district(pt):
    inside = [d for d, pg in poly.items() if pg.contains(pt)]
    if inside:
        return inside[0]
    d, pg = min(poly.items(), key=lambda kv: kv[1].distance(pt))   # coastal points off the simplified outline
    return d if pg.distance(pt) < 0.05 else None


host = {s: host_district(Point(r.longitude, r.latitude)) for s, r in stations.iterrows()}
rows = []
for _, r in mapping.iterrows():
    pg = poly[r.district]
    c = pg.centroid if pg.centroid.within(pg) else pg.representative_point()
    dist = {s: km(c, Point(v.longitude, v.latitude)) for s, v in stations.iterrows()}
    nearest = min(dist, key=dist.get)
    own = [s for s, h in host.items() if h == r.district]
    rows.append({"district": r.district, "station_name": r.station_name,
                 "station_in_district": host[r.station_name] == r.district,
                 "district_has_station": bool(own), "nearest_station_to_centroid": nearest,
                 "assigned_is_nearest": nearest == r.station_name,
                 "km_centroid_to_assigned": round(dist[r.station_name], 1),
                 "km_centroid_to_nearest": round(dist[nearest], 1)})
sa = pd.DataFrame(rows)
sa.to_csv(TAB / "station_assignment.csv", index=False)
linked = sa[~sa.station_in_district]
notnear = linked[~linked.assigned_is_nearest]
facts["stations"] = {
    "n_stations": int(len(stations)),
    "n_districts_with_station": int(sa.district_has_station.sum()),
    "n_districts_using_own_station": int(sa.station_in_district.sum()),
    "n_districts_linked_elsewhere": int(len(linked)),
    "n_linked_to_nearest": int(linked.assigned_is_nearest.sum()),
    "n_linked_not_nearest": int(len(notnear)),
    "extra_km_not_nearest_min": float((notnear.km_centroid_to_assigned - notnear.km_centroid_to_nearest).min()),
    "extra_km_not_nearest_max": float((notnear.km_centroid_to_assigned - notnear.km_centroid_to_nearest).max()),
    "km_centroid_to_assigned_median_linked": float(linked.km_centroid_to_assigned.median()),
    "km_centroid_to_assigned_max": float(sa.km_centroid_to_assigned.max()),
    "max_districts_per_station": int(mapping.n_districts_sharing_station.max()),
    "districts_not_nearest": notnear.district.tolist(),
}

# ------------------------------------------------------------------ 1a/Table 4. FAOSTAT comparison
fao_raw = pd.read_csv(DL / "faostat/Production_Crops_Livestock_E_Asia_NOFLAG.csv", encoding="latin-1")
fao_flag = pd.read_csv(DL / "faostat/Production_Crops_Livestock_E_Asia.csv", encoding="latin-1")
ITEMS = {"Rice": "Rice", "Potato": "Potatoes", "Jute": "Jute, raw or retted"}
sel = lambda df: df[(df.Area == "Bangladesh") & df.Item.isin(ITEMS.values())
                    & df.Element.isin(["Production", "Area harvested"])]
fb = sel(fao_raw)
ycols = [c for c in fb.columns if c[0] == "Y" and c[1:].isdigit() and 1984 <= int(c[1:]) <= 2023]
fao = fb.melt(id_vars=["Item", "Element"], value_vars=ycols, var_name="year", value_name="v")
fao["year"] = fao.year.str[1:].astype(int)
fao = fao.pivot_table(index=["Item", "year"], columns="Element", values="v").reset_index()
flags = sel(fao_flag)[[c + "F" for c in ycols]].stack().value_counts().to_dict()
facts["faostat_flags_1984_2023"] = {str(k): int(v) for k, v in flags.items()}
facts["faostat_release_file"] = "Production_Crops_Livestock_E_Asia (FAOSTAT QCL bulk download)"

bbs = []
for crop, item in ITEMS.items():
    sub = nat[nat.crop.isin(["Aus", "Aman", "Boro"])] if crop == "Rice" else nat[nat.crop == crop]
    g = sub.groupby("year")[["area_acres", "production"]].sum().reset_index()
    g["area_ha"] = g.area_acres * ACRE_HA
    g["prod_t"] = g.production * (JUTE_BALE_T if crop == "Jute" else 1.0)
    g["Item"] = item
    g["crop"] = crop
    bbs.append(g)
bbs = pd.concat(bbs)
cmp_ = bbs.merge(fao, on=["Item", "year"], how="inner")
cmp_["fao_yield"] = cmp_["Production"] / cmp_["Area harvested"]
cmp_["bbs_yield"] = cmp_.prod_t / cmp_.area_ha
cmp_.to_csv(TAB / "faostat_comparison_by_year.csv", index=False)


def corr(x, y):
    r, p = stats.pearsonr(x, y)
    z, se = np.arctanh(r), 1 / np.sqrt(len(x) - 3)
    return r, np.tanh(z - 1.96 * se), np.tanh(z + 1.96 * se), p


val = []
for crop in ITEMS:
    c = cmp_[cmp_.crop == crop]
    for meas, bx, fx in [("Area", "area_ha", "Area harvested"), ("Production", "prod_t", "Production"),
                         ("Yield", "bbs_yield", "fao_yield")]:
        r, lo, hi, p = corr(c[bx], c[fx])
        cs = c.sort_values("year")
        r_diff = stats.pearsonr(np.diff(np.log(cs[bx].values)), np.diff(np.log(cs[fx].values)))[0]
        val.append({"crop": crop, "measure": meas, "n": len(c), "r": r, "ci_low": lo, "ci_high": hi, "p": p,
                    "r_year_to_year": r_diff, "median_ratio_bbs_fao": float(np.median(c[bx] / c[fx]))})
val = pd.DataFrame(val)
val.round(4).to_csv(TAB / "validation_faostat.csv", index=False)
facts["validation"] = val.round(4).to_dict(orient="records")

# lag sensitivity (year convention check)
lag = []
for crop in ITEMS:
    b = bbs[bbs.crop == crop].drop(columns=["Item", "crop"]).set_index("year")
    f = fao[fao.Item == ITEMS[crop]].drop(columns=["Item"]).set_index("year")
    for L in (-1, 0, 1):
        f2 = f.copy()
        f2.index = f2.index - L
        j = b.join(f2, how="inner")
        lag.append({"crop": crop, "lag": L, "r_production": float(np.corrcoef(j.prod_t, j["Production"])[0, 1])})
facts["lag_sensitivity"] = lag

# ------------------------------------------------------------------ other facts for the text
def natv(crop, year, col):
    if crop == "Rice":
        return float(nat[nat.crop.isin(["Aus", "Aman", "Boro"]) & (nat.year == year)][col].sum())
    return float(nat[(nat.crop == crop) & (nat.year == year)][col].iloc[0])


facts["national"] = {f"{c}_{col}_{y}": natv(c, y, col) for c in CROPS + ["Rice"]
                     for col in ("area_acres", "production") for y in (1984, 2023)}
facts["counts"] = {"districts": int(clim.district.nunique()), "stations": int(clim.station_name.nunique()),
                   "years": int(clim.year.nunique()), "crop_records": int(len(long)),
                   "district_years": int(len(clim))}
facts["lat_range"] = [float(clim.latitude.min()), float(clim.latitude.max())]
facts["lon_range"] = [float(clim.longitude.min()), float(clim.longitude.max())]
facts["alt_range"] = [float(clim.altitude_m.min()), float(clim.altitude_m.max())]
(TAB / "facts.json").write_text(json.dumps(facts, indent=2))

# ------------------------------------------------------------------ Fig 1. map
fig, ax = plt.subplots(figsize=(4.6, 5.8))
for d, pg in poly.items():
    own = bool(sa.loc[sa.district == d, "station_in_district"].iloc[0])
    for part in (pg.geoms if pg.geom_type == "MultiPolygon" else [pg]):
        ax.add_patch(MplPolygon(np.asarray(part.exterior.coords), closed=True, lw=0.35, ec="white",
                                fc="#b7d3f6" if own else "#dddcd7"))
for _, r in sa[~sa.station_in_district].iterrows():
    pg = poly[r.district]
    c = pg.centroid if pg.centroid.within(pg) else pg.representative_point()
    s = stations.loc[r.station_name]
    ax.plot([c.x, s.longitude], [c.y, s.latitude], color=INK2, lw=0.6, zorder=3)
    ax.plot(c.x, c.y, "o", ms=2.2, color=INK2, zorder=3)
ax.scatter(stations.longitude, stations.latitude, s=26, color="#1c5cab", ec="white", lw=0.8, zorder=4)
LABEL_OFF = {"Madaripur": (4, -10), "Satkhira": (-14, -10), "Barisal": (-30, 4), "Rangpur": (-12, 7),
             "Jessore": (-30, -10), "Chandpur": (4, 3), "Khulna": (-8, 6), "Bhola": (4, -2)}
for s, v in stations.iterrows():
    ax.annotate(s, (v.longitude, v.latitude), xytext=LABEL_OFF.get(s, (3, 2)), textcoords="offset points",
                fontsize=5.2, color=INK, zorder=5,
                bbox=dict(boxstyle="square,pad=0.1", fc="white", ec="none", alpha=0.7))
ax.set_xlim(88.0, 92.75)
ax.set_ylim(20.55, 26.7)
ax.set_aspect(1 / np.cos(np.radians(23.7)))
ax.set_xlabel("Longitude (°E)")
ax.set_ylabel("Latitude (°N)")
ax.grid(False)
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
ax.legend(handles=[Patch(fc="#b7d3f6", label="District containing its assigned station"),
                   Patch(fc="#dddcd7", label="District linked to a station elsewhere"),
                   Line2D([], [], marker="o", ls="", ms=5, mfc="#1c5cab", mec="white", label="BMD station"),
                   Line2D([], [], color=INK2, lw=0.6, marker="o", ms=2.2, label="Link from district centre")],
          loc="lower left", fontsize=5.8, handlelength=1.4)
save(fig, "fig1_station_map")

# ------------------------------------------------------------------ Fig 2. workflow
fig, ax = plt.subplots(figsize=(7.0, 3.9))
ax.set_xlim(0, 100)
ax.set_ylim(0, 56)
ax.axis("off")


def box(x, y, w, h, text, fc="#f3f2ef", ec=MUTED, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.0", fc=fc, ec=ec, lw=0.7))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=5.6, color=INK,
            weight="bold" if bold else "normal", linespacing=1.3)


def arrow(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", lw=0.7, color=INK2,
                                                                  shrinkA=0, shrinkB=0))


BL = "#e8f1fc", "#86b6ef"
box(0.5, 44, 24, 9, "BMD station records, 1984-2013\n(from the Kaggle compilation\nof BMD data, 1948-2013)")
box(0.5, 32, 24, 9, "BMD station records\n2014-2023")
box(0.5, 16, 24, 9, "BBS: 45 Years Agriculture\nStatistics of Major Crops\n(to 2014-15)")
box(0.5, 4, 24, 9, "BBS: Yearbook of\nAgricultural Statistics\n(later years)")
box(29.5, 38, 20, 9, "Annual climate series\n26 stations, 7 variables", *BL)
box(29.5, 10, 20, 9, "Crop series, 64 districts\nAus, Aman, Boro,\njute, potato", *BL)
for y in (48.5, 36.5):
    arrow(25.1, y, 29.0, 42.5)
for y in (20.5, 8.5):
    arrow(25.1, y, 29.0, 14.5)
box(54.5, 24, 21, 9, "District-station link\n64 districts, 26 stations\n(Table A.1)")
arrow(50.1, 42.5, 54.0, 30.5)
arrow(50.1, 14.5, 54.0, 26.5)
box(54.5, 6, 21, 9, "Five merged crop files\n2,560 district-years each")
arrow(65, 23.5, 65, 15.6)
box(79.5, 32, 20, 12, "Package build:\nunit-labelled columns,\nlong and wide files,\nQC report, checksums", *BL)
box(79.5, 47, 20, 7.5, "CRU TS 4.10 grids:\ncrop-season climate layer", *BL)
arrow(89.5, 46.6, 89.5, 44.4)
box(79.5, 17, 20, 9, "Technical validation:\nFAOSTAT, USDA, disasters,\nGDHY; GSOD and CRU")
box(79.5, 3, 20, 9, "Mendeley Data\nrepository", fc="#cde2fb", ec="#3987e5", bold=True)
arrow(76.1, 10.5, 79.0, 36)
arrow(89.5, 31.5, 89.5, 26.6)
arrow(89.5, 16.5, 89.5, 12.6)
save(fig, "fig2_workflow")

# ------------------------------------------------------------------ Fig 3. national trends (small multiples)
fig, axes = plt.subplots(5, 3, figsize=(7.0, 8.2), sharex=True)
for i, crop in enumerate(CROPS):
    g = nat[nat.crop == crop]
    pu = "million bales" if crop == "Jute" else "million t"
    yu = "bales per acre" if crop == "Jute" else "t per acre"
    for j, (col, scale, lab) in enumerate([("area_acres", 1e6, "Area (million acres)"),
                                           ("production", 1e6, f"Production ({pu})"),
                                           ("yield", 1, f"Yield ({yu})")]):
        ax = axes[i, j]
        ax.plot(g.year, g[col] / scale, color=COL[crop], lw=1.6)
        ax.set_ylim(bottom=0)
        ax.set_ylabel(lab, fontsize=6.5)
        if j == 0:
            ax.set_title(crop, loc="left", fontsize=8, weight="bold", color=INK)
for ax in axes[-1]:
    ax.set_xlabel("Year")
fig.align_ylabels(axes)
fig.tight_layout(h_pad=0.8, w_pad=1.2)
save(fig, "fig3_national_trends")

# ------------------------------------------------------------------ Fig 4. district yield by period
long["period"] = ((long.year - 1984) // 5) * 5 + 1984
plab = {p: f"{p}-{str(p + 4)[2:]}" for p in range(1984, 2024, 5)}
fig, axes = plt.subplots(2, 3, figsize=(7.0, 4.6))
for ax, crop in zip(axes.flat, CROPS):
    g = long[long.crop == crop]
    data = [g[g.period == p]["yield"].values for p in sorted(plab)]
    bp = ax.boxplot(data, widths=0.6, patch_artist=True, showfliers=True,
                    medianprops=dict(color=INK, lw=1.0), whiskerprops=dict(color=INK2, lw=0.6),
                    capprops=dict(color=INK2, lw=0.6),
                    flierprops=dict(marker="o", ms=2, mfc=MUTED, mec="none", alpha=0.7))
    for b in bp["boxes"]:
        b.set(facecolor=COL[crop], edgecolor=INK2, lw=0.6, alpha=0.85)
    ax.set_xticks(range(1, len(plab) + 1), [plab[p] for p in sorted(plab)], rotation=45, ha="right", fontsize=6)
    ax.set_title(crop, loc="left", weight="bold")
    ax.set_ylabel("Yield (bales per acre)" if crop == "Jute" else "Yield (t per acre)", fontsize=6.5)
axes.flat[-1].axis("off")
axes.flat[-1].text(0.02, 0.6, "Each box: the 64 districts over the\nfive years of the period (n = 320).\n"
                   "Boxes span the interquartile range;\nwhiskers reach 1.5 times that range.",
                   fontsize=6.5, color=INK2, va="center", transform=axes.flat[-1].transAxes)
fig.tight_layout()
save(fig, "fig4_district_yield_boxplots")

# ------------------------------------------------------------------ Fig 5. climate across stations
fig, axes = plt.subplots(4, 2, figsize=(7.0, 7.4), sharex=True)
for ax, (col, lab) in zip(axes.flat, CLIM):
    q = station_year.groupby("year")[col].quantile([0.0, 0.25, 0.5, 0.75, 1.0]).unstack()
    ax.fill_between(q.index, q[0.0], q[1.0], color="#cde2fb", lw=0, label="Range over 26 stations")
    ax.fill_between(q.index, q[0.25], q[0.75], color="#86b6ef", lw=0, label="Interquartile range")
    ax.plot(q.index, q[0.5], color="#1c5cab", lw=1.6, label="Median station")
    ax.set_title(lab, loc="left")
axes[-1, 0].set_xlabel("Year")
axes[-2, 1].set_xlabel("Year")
axes[-2, 1].tick_params(labelbottom=True)
axes.flat[-1].axis("off")
h, l = axes.flat[0].get_legend_handles_labels()
axes.flat[-1].legend(h, l, loc="center left", fontsize=7)
fig.tight_layout()
save(fig, "fig5_climate_by_year")

# ------------------------------------------------------------------ Fig 6. validation scatter
fig, axes = plt.subplots(3, 3, figsize=(7.0, 6.9))
crop_col = {"Rice": COL["Aman"], "Potato": COL["Potato"], "Jute": COL["Jute"]}
spec = [("Area", "Area harvested", "area_ha", 1e6, "million ha"),
        ("Production", "Production", "prod_t", 1e6, "million t"),
        ("Yield", "fao_yield", "bbs_yield", 1, "t per ha")]
for i, crop in enumerate(ITEMS):
    c = cmp_[cmp_.crop == crop]
    for j, (meas, fx, bx, sc, unit) in enumerate(spec):
        ax = axes[i, j]
        x, y = c[fx] / sc, c[bx] / sc
        lim = [0, max(x.max(), y.max()) * 1.06]
        ax.plot(lim, lim, ls="--", lw=0.8, color=MUTED)
        ax.scatter(x, y, s=16, color=crop_col[crop], ec="white", lw=0.4, zorder=3)
        ax.set_xlim(lim)
        ax.set_ylim(lim)
        ax.set_aspect("equal")
        rr = val[(val.crop == crop) & (val.measure == meas)].iloc[0]
        ax.text(0.04, 0.95, f"r = {rr.r:.3f}", transform=ax.transAxes, va="top", fontsize=6.8, color=INK)
        ax.set_xlabel(f"FAOSTAT ({unit})", fontsize=6.5)
        ax.set_ylabel(f"This dataset ({unit})", fontsize=6.5)
        ax.set_title(f"{crop}: {meas.lower()}", loc="left", weight="bold")
fig.tight_layout()
save(fig, "fig6_faostat_validation")

# ------------------------------------------------------------------ LaTeX tables
def fmt(v, nd):
    return f"{v:,.{nd}f}".replace(",", "{,}")


# Table 3: summary statistics
rows3 = []
for col, lab in CLIM:
    s = stats_tbl[(stats_tbl.table.str.startswith("climate")) & (stats_tbl.variable == col)].iloc[0]
    rows3.append(("Climate (station-year, n = 1{,}040)", lab.replace("°C", "\\textdegree C").replace("%", "\\%"), s, 2))
crop_vars = {"aman": "production_t", "aus": "production_t", "boro": "production_t", "potato": "production_t",
             "jute": "production_bales"}
for crop in ["aus", "aman", "boro", "jute", "potato"]:
    t = f"crop_{crop} (district-year)"
    pu = "bales" if crop == "jute" else "t"
    ycol = "yield_bales_per_acre" if crop == "jute" else "yield_t_per_acre"
    for col, lab, nd in [("area_acres", "Area (acres)", 0), (crop_vars[crop], f"Production ({pu})", 0),
                         (ycol, f"Yield ({pu} per acre)", 3)]:
        s = stats_tbl[(stats_tbl.table == t) & (stats_tbl.variable == col)].iloc[0]
        rows3.append((f"{crop.capitalize()} (district-year, n = 2{{,}}560)", lab, s, nd))
lines = ["\\begin{tabular}{lrrrrr}", "\\toprule",
         "Variable & Mean & SD & Min & Median & Max \\\\", "\\midrule"]
last = None
for grp, lab, s, nd in rows3:
    if grp != last:
        if last is not None:
            lines.append("\\addlinespace")
        lines.append(f"\\multicolumn{{6}}{{l}}{{\\textit{{{grp}}}}} \\\\")
    lines.append(f"\\quad {lab} & {fmt(s['mean'], nd)} & {fmt(s['sd'], nd)} & "
                 f"{fmt(s['min'], nd)} & {fmt(s['median'], nd)} & {fmt(s['max'], nd)} \\\\")
    last = grp
lines += ["\\bottomrule", "\\end{tabular}"]
(TAB / "table3_summary_statistics.tex").write_text("\n".join(lines) + "\n")

# Table 4: validation
lines = ["\\begin{tabular}{llrrcrrr}", "\\toprule",
         "Crop & Measure & $n$ & $r$ & 95\\% CI & $p$ & $r$ of changes & Median ratio \\\\", "\\midrule"]
last = None
for _, v in val.iterrows():
    if last is not None and v.crop != last:
        lines.append("\\addlinespace")
    p = "$<$0.001" if v.p < 0.001 else f"{v.p:.3f}"
    lines.append(f"{v.crop if v.crop != last else ''} & {v.measure} & {v.n} & {v.r:.3f} & "
                 f"{v.ci_low:.3f} to {v.ci_high:.3f} & {p} & {v.r_year_to_year:.3f} & {v.median_ratio_bbs_fao:.3f} \\\\")
    last = v.crop
lines += ["\\bottomrule", "\\end{tabular}"]
(TAB / "table4_validation.tex").write_text("\n".join(lines) + "\n")

# Table 5: district-station mapping (longtable body)
m5 = mapping.drop(columns=[c for c in ("station_in_district", "nearest_station", "nearest_station_number", "km_centre_to_assigned", "km_centre_to_nearest") if c in mapping.columns]).merge(sa[["district", "station_in_district", "km_centroid_to_assigned"]], on="district")
lines = []
for _, r in m5.sort_values("district").iterrows():
    lines.append(f"{r.district.replace(chr(39), chr(39))} & {r.station_name} & {r.station_number} & "
                 f"{r.latitude:.2f} & {r.longitude:.2f} & {r.altitude_m:g} & "
                 f"{'yes' if r.station_in_district else 'no'} & {r.km_centroid_to_assigned:.0f} \\\\")
(TAB / "table5_mapping_rows.tex").write_text("\n".join(lines) + "\n")

print(json.dumps({k: facts[k] for k in ("stations", "faostat_flags_1984_2023", "counts")}, indent=1))
print(val.round(3).to_string(index=False))
print(pd.DataFrame(lag).pivot(index="crop", columns="lag", values="r_production").round(4))
