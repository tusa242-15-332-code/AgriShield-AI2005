#!/usr/bin/env python3
"""
Add the CRU TS crop-season climate layers to the repository package.

Usage:
    python add_external_layers.py <package_root> <downloads_dir>

Inputs (from fetch_external.py):
  <downloads>/cru/<var>/cru_ts4.10.<decade>.<var>.dat.nc.gz   CRU TS 4.10, monthly, 0.5 degree, 1981-2025
  <downloads>/geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson
  <downloads>/district_centroids.csv
Outputs (repository package):
  data/processed/cru_monthly_by_district.csv     64 districts x 492 months (1983-2023), district-area means
  data/processed/cru_crop_season_climate.csv     64 districts x 40 harvest years x 5 crops = 12,800 rows
  metadata/district_centroids.csv
  metadata/crop_seasons.csv                      the season windows used
  metadata/district_station_mapping.csv          adds station_in_district, nearest_station and distances
                                                 (run after build_package.py, which writes the base table)
District values are means of the 0.5 degree cells overlapping each district, weighted by overlap area.
The original BBS and BMD values are not read or changed. Needs pandas, numpy, netCDF4, shapely.
"""
import gzip
import json
import shutil
import sys
from pathlib import Path

import netCDF4
import numpy as np
import pandas as pd
from shapely.geometry import box, shape

PKG, DL = (Path(a).resolve() for a in sys.argv[1:3])
XW = {"Brahamanbaria": "Brahmanbaria", "Nawabganj": "Chapai Nawabganj",
      "Maulvibazar": "Moulvibazar", "Netrakona": "Netrokona"}
VARS = ["tmx", "tmn", "pre", "vap", "cld", "wet"]
DECADES = ["1981.1990", "1991.2000", "2001.2010", "2011.2020", "2021.2025"]

# Season windows relative to the harvest year Y (the dataset's `year` label):
# (start_month, start_year_offset, end_month): from start_month of Y+offset through end_month of Y.
SEASONS = {
    "Aus": (4, 0, 8),       # April-August Y
    "Aman": (7, 0, 11),     # July-November Y
    "Boro": (12, -1, 5),    # December Y-1 to May Y
    "Jute": (3, 0, 9),      # March-September Y
    "Potato": (11, -1, 3),  # November Y-1 to March Y
}


def load_var(var):
    """Return (lat, lon, dates, data[time, lat, lon], stn[time, lat, lon]) for the Bangladesh window."""
    data, stn, dates = [], [], []
    lat = lon = None
    for dec in DECADES:
        gz = DL / "cru" / var / f"cru_ts4.10.{dec}.{var}.dat.nc.gz"
        nc = gz.with_suffix("")
        if not nc.exists():
            with gzip.open(gz, "rb") as fi, open(nc, "wb") as fo:
                shutil.copyfileobj(fi, fo)
        ds = netCDF4.Dataset(nc)
        la, lo = ds["lat"][:], ds["lon"][:]
        ii = np.where((la > 20) & (la < 27))[0]
        jj = np.where((lo > 87.5) & (lo < 93))[0]
        lat, lon = la[ii], lo[jj]
        t = netCDF4.num2date(ds["time"][:], ds["time"].units, only_use_cftime_datetimes=False)
        dates += [(d.year, d.month) for d in t]
        data.append(np.ma.filled(ds[var][:, ii[0]:ii[-1] + 1, jj[0]:jj[-1] + 1].astype(float), np.nan))
        stn.append(np.ma.filled(ds["stn"][:, ii[0]:ii[-1] + 1, jj[0]:jj[-1] + 1].astype(float), np.nan))
        ds.close()
    return lat, lon, dates, np.concatenate(data), np.concatenate(stn)


def weights(lat, lon):
    gj = json.load(open(DL / "geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson"))
    w = {}
    for f in gj["features"]:
        d = XW.get(f["properties"]["shapeName"], f["properties"]["shapeName"])
        pg = shape(f["geometry"])
        cells = []
        for i, la in enumerate(lat):
            for j, lo in enumerate(lon):
                a = pg.intersection(box(lo - 0.25, la - 0.25, lo + 0.25, la + 0.25)).area
                if a > 0:
                    cells.append((i, j, a))
        w[d] = cells
    return w


def augment_mapping():
    """Add the nearest-station alternative to the district-station table."""
    gj = json.load(open(DL / "geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson"))
    poly = {XW.get(f["properties"]["shapeName"], f["properties"]["shapeName"]): shape(f["geometry"]) for f in gj["features"]}
    m = pd.read_csv(PKG / "metadata/district_station_mapping.csv")
    m = m[[c for c in m.columns if c not in ("station_in_district", "nearest_station", "nearest_station_number",
                                            "km_centre_to_assigned", "km_centre_to_nearest")]]
    st = m.drop_duplicates("station_name").set_index("station_name")[["station_number", "latitude", "longitude"]]

    def km(ax, ay, bx, by):
        lat = np.radians((ay + by) / 2)
        return float(np.hypot((ax - bx) * 111.32 * np.cos(lat), (ay - by) * 110.57))

    def host(lon, lat):
        from shapely.geometry import Point
        pt = Point(lon, lat)
        inside = [d for d, pg in poly.items() if pg.contains(pt)]
        if inside:
            return inside[0]
        d, pg = min(poly.items(), key=lambda kv: kv[1].distance(pt))
        return d if pg.distance(pt) < 0.05 else None

    hosts = {s: host(r.longitude, r.latitude) for s, r in st.iterrows()}
    rows = []
    for _, r in m.iterrows():
        pg = poly[r.district]
        c = pg.centroid if pg.centroid.within(pg) else pg.representative_point()
        dist = {s: km(c.x, c.y, v.longitude, v.latitude) for s, v in st.iterrows()}
        near = min(dist, key=dist.get)
        rows.append({"station_in_district": hosts[r.station_name] == r.district, "nearest_station": near,
                     "nearest_station_number": int(st.loc[near, "station_number"]),
                     "km_centre_to_assigned": round(dist[r.station_name], 1), "km_centre_to_nearest": round(dist[near], 1)})
    m = pd.concat([m.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
    m.to_csv(PKG / "metadata/district_station_mapping.csv", index=False)
    print("mapping: nearest station differs for", int((m.nearest_station != m.station_name).sum()), "districts")


def main():
    frames = {}
    W = None
    for v in VARS:
        lat, lon, dates, arr, stn = load_var(v)
        if W is None:
            W = weights(lat, lon)
        rows = []
        for d, cells in W.items():
            ii = np.array([c[0] for c in cells])
            jj = np.array([c[1] for c in cells])
            aw = np.array([c[2] for c in cells])
            vals = arr[:, ii, jj]
            ok = np.isfinite(vals)
            val = np.where(ok, vals, 0).dot(aw) / np.where(ok, 1, 0).dot(aw)
            sv = np.nan_to_num(stn[:, ii, jj]).dot(aw) / aw.sum()
            for k, (y, m) in enumerate(dates):
                rows.append((d, y, m, val[k], sv[k]))
        frames[v] = pd.DataFrame(rows, columns=["district", "year", "month", v, f"stn_{v}"])
        print("loaded", v, flush=True)
    mon = frames[VARS[0]]
    for v in VARS[1:]:
        mon = mon.merge(frames[v], on=["district", "year", "month"])
    mon = mon[(mon.year >= 1983) & (mon.year <= 2023)].copy()
    mon["cld"] = mon["cld"] * 8 / 100                     # percent -> okta
    mon = mon.rename(columns={"tmx": "tmax_mean_c", "tmn": "tmin_mean_c", "pre": "rain_total_mm",
                              "vap": "vapour_pressure_hpa", "cld": "cloud_mean_okta", "wet": "wet_days"})
    mon = mon.sort_values(["district", "year", "month"]).reset_index(drop=True)
    vals = ["tmax_mean_c", "tmin_mean_c", "rain_total_mm", "vapour_pressure_hpa", "cloud_mean_okta", "wet_days"]
    assert len(mon) == 64 * 41 * 12 and mon[vals].isna().sum().sum() == 0

    sea = []
    mon["ym"] = mon.year * 12 + mon.month - 1
    for crop, (sm, off, em) in SEASONS.items():
        for y in range(1984, 2024):
            a, b = (y + off) * 12 + sm - 1, y * 12 + em - 1
            s = mon[(mon.ym >= a) & (mon.ym <= b)]
            g = s.groupby("district")
            assert g.size().eq(b - a + 1).all()
            agg = pd.DataFrame({
                "tmax_mean_c": g.tmax_mean_c.mean(), "tmin_mean_c": g.tmin_mean_c.mean(),
                "rain_total_mm": g.rain_total_mm.sum(), "vapour_pressure_hpa": g.vapour_pressure_hpa.mean(),
                "cloud_mean_okta": g.cloud_mean_okta.mean(), "wet_days": g.wet_days.sum(),
                "cru_stations_tmx": g.stn_tmx.mean(), "cru_stations_pre": g.stn_pre.mean()}).reset_index()
            agg.insert(1, "year", y)
            agg.insert(2, "crop", crop)
            agg.insert(3, "season_start", f"{y + off}-{sm:02d}")
            agg.insert(4, "season_end", f"{y}-{em:02d}")
            sea.append(agg)
    sea = pd.concat(sea).sort_values(["crop", "district", "year"]).reset_index(drop=True)
    num = [c for c in sea.columns if sea[c].dtype.kind == "f"]
    sea[num] = sea[num].round(3)
    mon = mon.drop(columns="ym")
    mnum = [c for c in mon.columns if mon[c].dtype.kind == "f"]
    mon[mnum] = mon[mnum].round(3)
    mon = mon.rename(columns={c: c.replace("stn_", "cru_stations_") for c in mon.columns if c.startswith("stn_")})
    assert len(sea) == 12800 and sea.isna().sum().sum() == 0
    mon.to_csv(PKG / "data/processed/cru_monthly_by_district.csv", index=False)
    sea.to_csv(PKG / "data/processed/cru_crop_season_climate.csv", index=False)
    shutil.copy2(DL / "district_centroids.csv", PKG / "metadata/district_centroids.csv")
    augment_mapping()
    pd.DataFrame([{"crop": c, "start_month": sm, "start_year": "Y-1" if off else "Y", "end_month": em,
                   "end_year": "Y"} for c, (sm, off, em) in SEASONS.items()]).to_csv(
        PKG / "metadata/crop_seasons.csv", index=False)
    print("monthly rows", len(mon), "| season rows", len(sea))
    print(sea.groupby("crop")[["tmax_mean_c", "tmin_mean_c", "rain_total_mm", "wet_days", "cru_stations_tmx",
                               "cru_stations_pre"]].mean().round(2))
    print("share of district-months with zero CRU tmx stations:", round(float((mon.cru_stations_tmx == 0).mean()), 3),
          "| pre:", round(float((mon.cru_stations_pre == 0).mean()), 3))


if __name__ == "__main__":
    main()
