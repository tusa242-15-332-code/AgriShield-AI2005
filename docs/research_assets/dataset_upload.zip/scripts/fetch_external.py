#!/usr/bin/env python3
"""
Download the external reference data used for validation, the crop-season climate layer and the benchmark.

Usage:
    python fetch_external.py <package_root> <downloads_dir>

Writes (resumable; files already present are skipped):
  <downloads>/district_centroids.csv                 64 district centres (geoBoundaries ADM2)
  <downloads>/gsod/<year>/<WMO>099999.csv            NOAA Global Summary of the Day, 26 BMD stations, 1984-2023
  <downloads>/cru/<var>/cru_ts4.10.<decade>.<var>.dat.nc.gz
                                                     CRU TS 4.10 monthly 0.5 degree grids, 1981-2025,
                                                     variables tmx tmn pre vap cld wet
  <downloads>/usda_psd/psd_grains_pulses_csv.zip     USDA FAS PSD bulk file
  <downloads>/gdhy/gdhy_v1.2_v1.3_20190128.zip       GDHY v1.2+v1.3 (PANGAEA 10.1594/PANGAEA.909132)
Needs shapely, pandas and certifi.
"""
import json
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import certifi
import pandas as pd
from shapely.geometry import shape

PKG, DL = (Path(a).resolve() for a in sys.argv[1:3])
UA = {"User-Agent": "dataset-validation-script/1.0"}
CTX = ssl.create_default_context(cafile=certifi.where())
XW = {"Brahamanbaria": "Brahmanbaria", "Nawabganj": "Chapai Nawabganj",
      "Maulvibazar": "Moulvibazar", "Netrakona": "Netrokona"}
CRU = "https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.10/cruts.2604091129.v4.10"
CRU_VARS = ["tmx", "tmn", "pre", "vap", "cld", "wet"]
DECADES = ["1981.1990", "1991.2000", "2001.2010", "2011.2020", "2021.2025"]


def get(url, path, timeout=300):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
        data = r.read()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return len(data)


def get_retry(url, path, tries=3):
    if path.exists() and path.stat().st_size > 0:
        return "skip"
    for k in range(tries):
        try:
            get(url, path)
            return "ok"
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return "404"
            time.sleep(5 * (k + 1))
        except Exception:
            time.sleep(5 * (k + 1))
    return "fail"


def centroids():
    gj = json.load(open(DL / "geoboundaries/geoBoundaries-BGD-ADM2_simplified.geojson"))
    rows = []
    for f in gj["features"]:
        g = shape(f["geometry"])
        c = g.centroid if g.centroid.within(g) else g.representative_point()
        rows.append({"district": XW.get(f["properties"]["shapeName"], f["properties"]["shapeName"]),
                     "latitude": round(c.y, 4), "longitude": round(c.x, 4),
                     "centroid_inside_polygon": bool(g.centroid.within(g))})
    pd.DataFrame(rows).sort_values("district").to_csv(DL / "district_centroids.csv", index=False)


def main():
    centroids()
    status = {}
    status["usda"] = get_retry("https://apps.fas.usda.gov/psdonline/downloads/psd_grains_pulses_csv.zip",
                               DL / "usda_psd/psd_grains_pulses_csv.zip")
    status["gdhy"] = get_retry("https://store.pangaea.de/Publications/IizumiT_2019/gdhy_v1.2_v1.3_20190128.zip",
                               DL / "gdhy/gdhy_v1.2_v1.3_20190128.zip")
    for v in CRU_VARS:
        for dec in DECADES:
            fn = f"cru_ts4.10.{dec}.{v}.dat.nc.gz"
            status[f"cru/{fn}"] = get_retry(f"{CRU}/{v}/{fn}", DL / "cru" / v / fn)
        print("CRU", v, flush=True)
    st = pd.read_csv(PKG / "metadata/district_station_mapping.csv").drop_duplicates("station_number")
    for _, r in st.iterrows():
        for y in range(1984, 2024):
            fid = f"{r.station_number}099999.csv"
            status[f"gsod/{y}/{fid}"] = get_retry(
                f"https://www.ncei.noaa.gov/data/global-summary-of-the-day/access/{y}/{fid}", DL / "gsod" / str(y) / fid)
            time.sleep(0.1)
        print("GSOD", r.station_name, flush=True)
    (DL / "fetch_status.json").write_text(json.dumps(status, indent=1))
    print("SUMMARY", pd.Series(status).value_counts().to_dict())


if __name__ == "__main__":
    main()
